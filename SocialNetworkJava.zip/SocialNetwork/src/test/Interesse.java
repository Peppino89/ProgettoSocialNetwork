package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Interesse {
	private static final String DB_URL="jdbc:mysql://localhost:3306/social_network";
	private static final String DB_USERNAME="root";
	private static final String DB_PASSWORD="Partenopeo.1926";
	private int id;
	private String nome;

	public Interesse() {

	}
	public Interesse(String nome) {
		this.nome = nome;
	}
	public int getIdInteresse(String interesse) {
		int idInteresse = -1;
		try(Connection conn = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD)){

			conn.setAutoCommit(false);//disabilitiamo il metodo predefinito della scrittura dati su DB
			try(PreparedStatement pstmt= conn.prepareStatement("SELECT id FROM interessi WHERE nome = ?")){
				//inserimento studente

				pstmt.setString(1, interesse);



				//esecuzione della query
				ResultSet rs = pstmt.executeQuery();

				while(rs.next()){
					idInteresse = rs.getInt("id");
				}



				conn.commit();//avvio della transazione


			}catch(SQLException e) {
				conn.rollback();//metodo per annullare l'inserimento avvenuto in modo parziale
				e.printStackTrace();
			}finally {
				conn.setAutoCommit(true);//riabilitiamo l'autocommit

			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return idInteresse;
	}
}