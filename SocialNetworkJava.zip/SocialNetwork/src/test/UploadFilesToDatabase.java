package test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UploadFilesToDatabase {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/social_network";
    private static final String USER = "root";
    private static final String PASS = "root";

    public static void main(String[] args) {
//       // Scriptcopy scriptcopy = new Scriptcopy();
//        String cssFilePath = "C:\\Users\\Dell\\Desktop\\SocialNetwork\\styles.css";
//        String jsFilePath = scriptcopy.getJavascript().toString();
//        
        try {
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);

//            uploadFile(conn, cssFilePath, "css");
//            uploadFile(conn, jsFilePath, "js");

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void uploadFile(Connection conn, String filePath, String fileType) {
        String fileName = filePath.substring(filePath.lastIndexOf("\\") + 1);
        StringBuilder contentBuilder = new StringBuilder();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                contentBuilder.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        String content = contentBuilder.toString();

        if (fileExists(conn, fileName, fileType)) {
            System.out.println("File " + fileName + " giÃ  presente sul Database.");
            return;
        }

        String query = "INSERT INTO assets (name, type, content) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, fileName);
            pstmt.setString(2, fileType);
            pstmt.setString(3, content);
            pstmt.executeUpdate();
            System.out.println("File " + fileName + " caricato correttamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static boolean fileExists(Connection conn, String fileName, String fileType) {
        String query = "SELECT 1 FROM assets WHERE name = ? AND type = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, fileName);
            pstmt.setString(2, fileType);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next(); // Return true if a result is found
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
