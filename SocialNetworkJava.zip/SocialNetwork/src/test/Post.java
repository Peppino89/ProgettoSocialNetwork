package test;

import java.sql.Timestamp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.imageio.ImageIO;


public class Post {
	//attributi
	private int idPost;

	private String immagine;
	private String descrizione;
	private Timestamp dataPost;
	private int idUtente;
	private int idInteresse;

	private static final String URL = "jdbc:mysql://localhost:3306/social_network";
	private static final String USER = "root";
	private static final String PASSWORD = "Partenopeo.1926";
	public Post(String descrizione, Timestamp dataPost, int idUtente, int idInteresse) {
		this.descrizione = descrizione;
		this.dataPost = dataPost;
		this.idUtente = idUtente;
		this.idInteresse = idInteresse;
	}
	public Post() {

	}
	//metodi get e set
	private void setIdPost(int idPost) {
		this.idPost = idPost;
	}
	private void setIdInteresse(int idInteresse) {
		this.idInteresse = idInteresse;
	}
	private void setImmagine(String immagine) {
		this.immagine = immagine;
	}
	private void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	private void setDataPost(Timestamp dataPost) {
		this.dataPost = dataPost;
	}
	private void setIdUtente(int idUtente) {
		this.idUtente = idUtente;
	}
	public int getIdPost() {
		return idPost;
	}
	public int getIdInteresse() {
		return idInteresse;
	}
	public String getImmagine() {
		return immagine;
	}

	public String getDescrizione() {
		return descrizione;
	}
	public Timestamp getData() {
		return dataPost;
	}
	public int getIdUtente() {
		return idUtente;
	}


	//metodo che aggiunge un post anche con l'immagine (stand-by)
	public void aggiungiPostImmagine(String titolo, String immagine, String descrizione, int idUtente) throws IOException{
		String query = "INSERT INTO posts (titolo, immagine,descrizione, id_utente) VALUES (?,?,?,?)";
		//		File inputFile= new File(immagine);
		//		BufferedImage image = ImageIO.read(inputFile);
		String nomeFile = salvaImmaginePath(immagine);
		try(Connection conn = DriverManager.getConnection(URL,USER,PASSWORD);
				PreparedStatement pstmt = conn.prepareStatement(query)){
			// Genera un nome unico per il file di output
			//            String timeStamp = String.valueOf(new Date().getTime());
			//            String fileName = "post" + idUtente + "" + timeStamp + ".jpg";
			pstmt.setString(1, titolo);
			pstmt.setString(2, nomeFile);
			pstmt.setString(3, descrizione);
			pstmt.setInt(4, idUtente);

			int rowsInserted = pstmt.executeUpdate();
			//controllo se la riga è stata inserita
			if(rowsInserted > 0) {
				System.out.println("Un nuovo post è stato aggiunto con successo");
			}

		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//post senza immagine (per ora usare questo metodo)
	public void aggiungiPost(String descrizione, int idUtente, int idInteresse) throws IOException{
		String query = "INSERT INTO posts (descrizione,data_post, id_utente, id_interesse) VALUES (?,?,?,?)";

		try(Connection conn = DriverManager.getConnection(URL,USER,PASSWORD);
				PreparedStatement pstmt = conn.prepareStatement(query))
		{
			Timestamp dataPost = new Timestamp(new Date().getTime());
			pstmt.setString(1, descrizione);
			pstmt.setTimestamp(2, dataPost);
			pstmt.setInt(3, idUtente);
			pstmt.setInt(4, idInteresse);


			int rowsInserted = pstmt.executeUpdate();
			//controllo se la riga è stata inserita
			if(rowsInserted > 0) {
				System.out.println("Un nuovo post è stato aggiunto con successo");
			}

		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	//metodo che modifica il post anche con l'immagine (stand-by)
	public void modificaPostImmagine(int idPost, String titolo, String immagine, String descrizione) {
		String query = "UPDATE posts SET titolo = ? , immagine = ?, descrizione = ? WHERE id = ?";
		try(Connection conn = DriverManager.getConnection(URL,USER,PASSWORD);
			
			PreparedStatement pstmt = conn.prepareStatement(query)){
			pstmt.setString(1, titolo);
			pstmt.setString(2, immagine);
			pstmt.setString(3, descrizione);
			pstmt.setInt(4, idPost);

			int rowsInserted = pstmt.executeUpdate();
			//controllo se la riga è stata inserita
			if(rowsInserted > 0) {
				System.out.println("Post modificato con successo");
			}

		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	//metodo modifica post senza immagine (per ora usare questo metodo)
	public void modificaPost(int idPost, String titolo, String descrizione) {
		String query = "UPDATE posts SET titolo = ?, descrizione = ? WHERE id = ?";
		try(Connection conn = DriverManager.getConnection(URL,USER,PASSWORD);
				PreparedStatement pstmt = conn.prepareStatement(query)){
			pstmt.setString(1, titolo);
			pstmt.setString(2, descrizione);
			pstmt.setInt(3, idPost);
			int rowsInserted = pstmt.executeUpdate();
			//controllo se la riga è stata inserita
			if(rowsInserted > 0) {
				System.out.println("Post modificato con successo");
			}

		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	public void eliminaPost(int idPost) {
		String query = "DELETE FROM posts WHERE id = ?";
		try(Connection conn = DriverManager.getConnection(URL,USER,PASSWORD);
				PreparedStatement stmt = conn.prepareStatement(query)){
			stmt.setInt(1, idPost);
			stmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}



	public List<Post> visualizzaAllPost(int idUtente){
		List<Post> posts = new ArrayList<>();
		String query = "SELECT posts.descrizione, posts.data_post, utenti.username, interessi.nome "
				+ "FROM posts"
				+ "JOIN utenti ON posts.id_utente = utenti.id"
				+ "JOIN interessi ON posts.id_interesse = interessi.id"
				+ "WHERE posts.id_utente = ?";
		try (Connection conn = DriverManager.getConnection(URL,USER,PASSWORD);
				PreparedStatement pstmt = conn.prepareStatement(query);
				){
			pstmt.setInt(1, idUtente);

			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				Post post = new Post();

				post.setDescrizione(rs.getString("descrizione"));
				post.setImmagine(rs.getString("immagine"));
				post.setDataPost(rs.getTimestamp("data_post"));
				post.setIdUtente(rs.getInt("id_utente"));
				post.setIdInteresse(rs.getInt("id_interesse"));
				posts.add(post);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}

		return posts;
	}




	//da vedere (stand-by)
	public void aggiungiLike(int idUtente, int idPost) {
		String query = "INSERT INTO like_posts(id_utente, id_post) VALUES(?, ?)";
		try(Connection conn = DriverManager.getConnection(URL,USER,PASSWORD);
				PreparedStatement stmt = conn.prepareStatement(query)){
			stmt.setInt(1, idUtente);
			stmt.setInt(2, idPost);
			stmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}

	}
	//da vedere (stand-by)
	public void eliminaLike(int idPost) {
		String query = "DELETE FROM like_posts WHERE id = ?";
		try(Connection conn = DriverManager.getConnection(URL,USER,PASSWORD);
				PreparedStatement stmt = conn.prepareStatement(query)){
			stmt.setInt(1, idPost);
			stmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}

	}




	public String salvaImmaginePath(String immagine) {
		File outputFile = new File("");
		try {
			// Leggi l'immagine JPG da un file
			//        	File inputFile = new File("C:/bloccoNoteJava/facebook.png" + immagine);
			File inputFile = new File(immagine);
			BufferedImage image = ImageIO.read(inputFile);

			// Specifica la directory dove salvare l'immagine
			File outputDir = new File("C:/img");
			if (!outputDir.exists()) {
				outputDir.mkdirs();  // Crea la directory se non esiste
			}

			// Specifica il file di output
			outputFile = new File(outputDir, "immaggineSalvata.png");

			// Scrivi l'immagine in formato PNG
			ImageIO.write(image, "png", outputFile);

			System.out.println("Immagine salvata con successo in " + outputFile.getAbsolutePath());
		} catch (IOException e) {
			System.out.println("Errore durante la lettura o la scrittura dell'immagine: " + e.getMessage());
			e.printStackTrace();
		}
		return outputFile.toString();
	}
}