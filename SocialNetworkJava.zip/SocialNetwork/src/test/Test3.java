package test;

import com.sun.net.httpserver.HttpServer;
//import com.sun.net.httpserver.HttpHandler;
//import com.sun.net.httpserver.HttpExchange; 
import java.io.*;
import java.net.InetSocketAddress;
//import java.sql.*;
//import java.util.*;
import gestionehandler.RegistraHandler;
import gestionehandler.UserMessaggiHandler;
import gestionehandler.UserPageHandler;
import gestionehandler.AccediHandler;
import gestionehandler.HomePageHandler;
import gestionehandler.LoginErratoHandler;

public class Test3 {

	public static void main(String[] args) throws IOException {
		HttpServer server = HttpServer.create(new InetSocketAddress(8080),0);

		server.createContext("/", new HomePageHandler());
		server.createContext("/registra",new RegistraHandler());
		
		server.createContext("/accedi",new AccediHandler());
		server.createContext("/userMessaggi", new UserMessaggiHandler());
		server.createContext("/userPage",new UserPageHandler());
		server.createContext("/loginErrato",new LoginErratoHandler());
		server.start();
		System.out.println("Server in esecuzione 3");

	}
		
}
