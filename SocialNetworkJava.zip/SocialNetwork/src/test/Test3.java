package test;

import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;

import gestionehandler.RegistraHandler;
import gestionehandler.UserMessaggiHandler;
import gestionehandler.UserPageHandler;
import gestionehandler.AccediHandler;
import gestionehandler.AdminPageHandler;
import gestionehandler.HomePageHandler;
import gestionehandler.LoginErratoHandler;

public class Test3 {
	
String adminUsername = "admin";
String adminPassword = "admin";

	public static void main(String[] args) throws IOException {
		HttpServer server = HttpServer.create(new InetSocketAddress(8080),0);

		server.createContext("/", new HomePageHandler());
		server.createContext("/registra",new RegistraHandler());
		
		server.createContext("/accedi",new AccediHandler());
		server.createContext("/userMessaggi", new UserMessaggiHandler());
		server.createContext("/userPage",new UserPageHandler());
		server.createContext("/loginErrato",new LoginErratoHandler());
		server.createContext("/userAmministratore",new AdminPageHandler());
		server.start();
		System.out.println("Server in esecuzione 3");

	}
		
}
