package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Amministratore extends Utente {

	private int idAmministratore;
	private String username;
	private String password;
	private String email;
	private String domandaSegreta;
	private String rispostaSegreta;
	private int livello;

	private static final String DB_URL = "jdbc:mysql://localhost:3306/social_network";
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "root";

	// Getters and Setters
	public int getIdAmministratore() {
		return idAmministratore;
	}
	
	

	public void setIdAmministratore(int idAmministratore) {
		this.idAmministratore = idAmministratore;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDomandaSegreta() {
		return domandaSegreta;
	}

	public void setDomandaSegreta(String domandaSegreta) {
		this.domandaSegreta = domandaSegreta;
	}

	public String getRispostaSegreta() {
		return rispostaSegreta;
	}

	public void setRispostaSegreta(String rispostaSegreta) {
		this.rispostaSegreta = rispostaSegreta;
	}

	public int getLivello() {
		return livello;
	}

	public void setLivello(int livello) {
		this.livello = livello;
	}

	// Default constructor
	public Amministratore() {
	}

	// Method to add an administrator
	public void aggiungiAmministratore(Amministratore amministratore) {
		String sql = "INSERT INTO amministratori (username, password, email, domanda_segreta, risposta_segreta, livello) VALUES (?, ?, ?, ?, ?, ?)";

		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, amministratore.getUsername());
			pstmt.setString(2, amministratore.getPassword());
			pstmt.setString(3, amministratore.getEmail());
			pstmt.setString(4, amministratore.getDomandaSegreta());
			pstmt.setString(5, amministratore.getRispostaSegreta());
			pstmt.setInt(6, amministratore.getLivello());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Method to view users
	public List<Utente> visualizzaUtenti() {
		List<Utente> utenti = new ArrayList<>();
		String sql = "SELECT * FROM utenti";

		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery()) {
			Utente utente = new Utente();
			while (rs.next()) {

				utente.setIdUtente(rs.getInt("id"));
				utente.setNome(rs.getString("nome"));
				utente.setCognome(rs.getString("cognome"));
				utente.setUsername(rs.getString("username"));
				utente.setEmail(rs.getString("email"));
				utente.setPassword(rs.getString("password"));
				utente.setNumeroTelefono(rs.getString("telefono"));
				utente.setDomandaSegreta(rs.getString("domanda_segreta"));
				utente.setRispostaSegreta(rs.getString("risposta_segreta"));
				utente.setDataNascita(rs.getString("data_nascita"));
				utente.setDataRegistrazione(rs.getString("data_registrazione"));
				utenti.add(utente);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return utenti;
	}

	// Method to update user
	public void modificaUtente(int idUtente, Utente utenteModificato) {
		String sql = "UPDATE utenti SET nome = ?, cognome = ?, username = ?, email = ?, password = ?, telefono = ?, domanda_segreta = ?, risposta_segreta = ?, data_nascita = ? WHERE id = ?";

		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, utenteModificato.getNome());
			pstmt.setString(2, utenteModificato.getCognome());
			pstmt.setString(3, utenteModificato.getUsername());
			pstmt.setString(4, utenteModificato.getEmail());
			pstmt.setString(5, utenteModificato.getPassword());
			pstmt.setString(6, utenteModificato.getNumeroTelefono());
			pstmt.setString(7, utenteModificato.getDomandaSegreta());
			pstmt.setString(8, utenteModificato.getRispostaSegreta());
			pstmt.setString(9, utenteModificato.getDataNascita());
			pstmt.setInt(10, idUtente);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Method to delete user
	public boolean eliminaUtente(int idUtente) {
		boolean delete = false;
		String sql = "DELETE FROM utenti WHERE id = ?";

		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, idUtente);
			pstmt.executeUpdate();
			delete = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return delete;
	}
}