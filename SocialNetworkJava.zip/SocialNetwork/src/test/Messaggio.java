package test;

import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class Messaggio {

	private int idMessaggio;
	private Timestamp dataInvio;
	private String messaggio;
	private int idUtenteDestinatario;
	private int idUtenteMittente;
	private String usernameMittente;
	private String usernameDestinatario;


	private boolean isRead;

	private static final String DB_URL="jdbc:mysql://localhost:3306/social_network";
	private static final String DB_USERNAME="root";
	private static final String DB_PASSWORD="root";


	public Messaggio(Timestamp dataInvio, String messaggio, int idUtenteDestinatario, int idUtenteMittente) {

		this.dataInvio = dataInvio;
		this.messaggio = messaggio;
		this.idUtenteDestinatario = idUtenteDestinatario;
		this.idUtenteMittente = idUtenteMittente;

	}

	public Messaggio() {
	}

	public int getIdMessaggio() {
		return idMessaggio;
	}
	public Timestamp getDataMessaggio() {
		return dataInvio;
	}

	public String getMessaggio() {
		return messaggio;
	}

	public int getIdUtenteDestinatario() {
		return idUtenteDestinatario;
	}
	public int getIdUtenteMittente() {
		return idUtenteMittente;
	}

	public void setIdMessaggio(int idMessaggio) {
		this.idMessaggio = idMessaggio;
	}

	public void setDataMessaggio(Timestamp dataInvio) {
		this.dataInvio= dataInvio;
	}

	public void setMessaggio(String messaggio) {
		this.messaggio = messaggio;
	}

	public void setIdUtenteDestinatario(int idUtenteDestinatario) {
		this.idUtenteDestinatario = idUtenteDestinatario;
	}

	public void setIdUtenteMittente(int idUtenteMittente) {
		this.idUtenteMittente = idUtenteMittente;
	}

	public String getUsernameMittente() {
		return usernameMittente;
	}

	public void setUsernameMittente(String usernameMittente) {
		this.usernameMittente = usernameMittente;
	}

	public String getUsernameDestinatario() {
		return usernameDestinatario;
	}

	public void setUsernameDestinatario(String usernameDestinatario) {
		this.usernameDestinatario = usernameDestinatario;
	}


	public boolean insertMessaggio(String usernameDestinatario, String usernameMittente, String messaggio) {
		boolean isSent = false;
		String idQuery = "SELECT (SELECT id FROM utenti WHERE username = ?) AS destinatario, "
				+ "(SELECT id FROM utenti WHERE username = ?) AS mittente";
		String insertQuery = "INSERT INTO messaggi (data, messaggio, id_utente_destinatario, id_utente_mittente) VALUES (?, ?, ?, ?)";

		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
				PreparedStatement pstmtGetId = conn.prepareStatement(idQuery);
				PreparedStatement pstmtInsert = conn.prepareStatement(insertQuery)) {

			conn.setAutoCommit(false);

			// Imposta i parametri per ottenere gli ID
			pstmtGetId.setString(1, usernameDestinatario);
			pstmtGetId.setString(2, usernameMittente);

			try (ResultSet rs = pstmtGetId.executeQuery()) {
				if (rs.next()) {
					int idDestinatario = rs.getInt("destinatario");
					int idMittente = rs.getInt("mittente");

					// Ottiene la data e l'ora corrente
					Timestamp dataInvio = new Timestamp(new Date().getTime());


					pstmtInsert.setTimestamp(1, dataInvio);
					pstmtInsert.setString(2, messaggio);
					pstmtInsert.setInt(3, idDestinatario);
					pstmtInsert.setInt(4, idMittente);

					int createdRows = pstmtInsert.executeUpdate();
					if (createdRows > 0) {
						isSent = true;
					}
					conn.commit();

				} else {
					System.out.println("Destinatario o Mittente non trovato.");
					conn.rollback();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isSent;
	}


	//Query Eliminazione
	public void eliminaMessaggio(int idMessaggio) {
		try {

			Connection conn = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD);

			String sqlEliminazione = "DELETE FROM messaggi WHERE id= ?";

			PreparedStatement pstmtEliminazione = conn.prepareStatement(sqlEliminazione);

			pstmtEliminazione.setInt(1, idMessaggio);


			int eliminazione = pstmtEliminazione.executeUpdate();


			//Chiusura connessionni 
			pstmtEliminazione.close();
			conn.close();

		}
		catch(SQLException e) {
			e.printStackTrace();
		}

	}





	public List<Messaggio> visualizzaChat(int destinatario, int mittente) {
		List<Messaggio> messaggi = new ArrayList<>();
		String query = "SELECT messaggi.id, messaggi.data, messaggi.messaggio, utentiMittente.username AS mittente, utentiDestinatario.username AS destinatario " +
				"FROM messaggi " +
				"INNER JOIN utenti AS utentiMittente ON messaggi.id_utente_mittente = utentiMittente.id " +
				"INNER JOIN utenti AS utentiDestinatario ON messaggi.id_utente_destinatario = utentiDestinatario.id " +
				"WHERE (messaggi.id_utente_mittente = ? AND messaggi.id_utente_destinatario = ?) " +
				"   OR (messaggi.id_utente_mittente = ? AND messaggi.id_utente_destinatario = ?) " +
				"ORDER BY messaggi.data DESC";
		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
				PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setInt(1, mittente);
			pstmt.setInt(2, destinatario);

			pstmt.setInt(3, destinatario);
			pstmt.setInt(4, mittente);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Messaggio messaggio = new Messaggio();
				messaggio.setIdMessaggio(rs.getInt("id"));
				messaggio.setDataMessaggio(rs.getTimestamp("data"));
				messaggio.setMessaggio(rs.getString("messaggio"));
				messaggio.setUsernameMittente(rs.getString("mittente"));
				messaggio.setUsernameDestinatario(rs.getString("destinatario"));

				messaggi.add(messaggio);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return messaggi;
	}

	public List<Messaggio> visualizzaMiaChat(String username){

		List<Messaggio> messaggi = new ArrayList<>();
		String query = "SELECT mittente.username AS mittente_username, "
				+ "       messaggi.messaggio, "
				+ "       messaggi.data, "
				+ "       destinatario.username AS destinatario_username "
				+ "FROM messaggi "
				+ " JOIN utenti AS mittente ON messaggi.id_utente_mittente = mittente.id "
				+ " JOIN utenti AS destinatario ON messaggi.id_utente_destinatario = destinatario.id "
				+ "WHERE destinatario.username = ? ORDER BY messaggi.data DESC"; 
			
		
		try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
				PreparedStatement pstmt = conn.prepareStatement(query)) {

			//  pstmt.setInt(1, mittente);
			//            pstmt.setInt(2, destinatario);
			//            
			//            pstmt.setInt(3, destinatario);
			//            pstmt.setInt(4, mittente);
			
			pstmt.setString(1, username);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Messaggio messaggio = new Messaggio();
				messaggio.setDataMessaggio(rs.getTimestamp("data"));
				messaggio.setMessaggio(rs.getString("messaggio"));
				messaggio.setUsernameMittente(rs.getString("mittente_username"));
				messaggio.setUsernameDestinatario(rs.getString("destinatario_username"));
				messaggi.add(messaggio);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return messaggi;

	}

}
