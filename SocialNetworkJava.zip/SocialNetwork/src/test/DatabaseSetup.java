package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseSetup {
	
	public static final String URL = "jdbc:mysql://localhost:3306/";
	public static final String DB_NAME = "social_network";
	public static String user = "root";
	public static String password = "B4n4n4Spl1t!";
	
	public static void main(String[] args) {
		createDatabase();
		createTables();
	}
	
	public static void createDatabase() {
		String createDbQuery = "CREATE DATABASE IF NOT EXISTS " + DB_NAME;
		try(Connection conn = DriverManager.getConnection(URL, user, password);
			Statement stmt = conn.createStatement()){
			stmt.executeUpdate(createDbQuery);
			System.out.println("Database creato con successo!");
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	
	private static void createTables() {
		
		String tabellaMessaggi = "CREATE TABLE IF NOT EXISTS messaggi("
									+ "id INT AUTO_INCREMENT PRIMARY KEY, "
									+ "data TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL, "
									+ "messaggio TEXT NOT NULL, "
									+ "id_utente_destinatario INT NOT NULL, "
									+ "id_utente_mittente INT NOT NULL)";
		
		
		String tabellaAmministratori = "CREATE TABLE IF NOT EXISTS amministratori("
									+ "id INT AUTO_INCREMENT PRIMARY KEY, "
									+ "username VARCHAR(50) NOT NULL, "
									+ "password VARCHAR(50) NOT NULL, "
									+ "email VARCHAR(50) NOT NULL, "
									+ "domanda_segreta VARCHAR(100) NOT NULL, "
									+ "risposta_segreta VARCHAR(100) NOT NULL, "
									+ "livello INT NOT NULL)";
		
		String tabellaLikePosts = "CREATE TABLE IF NOT EXISTS like_posts("
								+ "id INT AUTO_INCREMENT PRIMARY KEY, "
								+ "id_utente INT NOT NULL, "
								+ "id_post INT NOT NULL)";
		
		String tabellaFollowers = "CREATE TABLE IF NOT EXISTS followers("
								+ "id INT AUTO_INCREMENT PRIMARY KEY, "
								+ "id_utente_seguace INT NOT NULL, "
								+ "id_utente_seguito INT NOT NULL)";
		
		String tabellaAmicizie = "CREATE TABLE IF NOT EXISTS amicizie("
								+ "id INT AUTO_INCREMENT PRIMARY KEY, "
								+ "id_utente_seguace INT NOT NULL, "
								+ "id_utente_seguito INT NOT NULL)";
		
		String tabellaGruppi = "CREATE TABLE IF NOT EXISTS gruppi("
							+ "id INT AUTO_INCREMENT NOT NULL PRIMARY KEY, "
							+ "titolo VARCHAR(100) NOT NULL, "
							+ "descrizione TEXT, "
							+ "data_creazione DATE NOT NULL, "
							+ "id_utente INT NOT NULL, "
							+ "id_interesse INT NOT NULL)";
		
		String tabellaUtenti = "CREATE TABLE IF NOT EXISTS utenti (" 
	              +  "id INT AUTO_INCREMENT PRIMARY KEY, " 
	              +  "nome VARCHAR(100) NOT NULL, " 
	              +  "cognome VARCHAR(100) NOT NULL, " 
	              +  "username VARCHAR(100) NOT NULL, " 
	              +  "passowrd VARCHAR(100) NOT NULL, "
	              +  "email VARCHAR(100) UNIQUE NOT NULL, "
	              +  "immagine VARCHAR(250), "
	              +  "telefono VARCHAR(100) NOT NULL, "
	              +  "domanda_segreta VARCHAR(150) NOT NULL, "
	              +  "risposta_segreta VARCHAR(150) NOT NULL, "
	              +  "data_nascita DATE NOT NULL, "
	              +  "data_registrazione TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
	              +  "id_interesse INT NOT NULL "
	              + "is_logged BOOLEAN"
	              + ")"; 
	  	  
	  	  String tabellaInteressi = "CREATE TABLE IF NOT EXISTS interessi ("
	  	  		                   + "id INT AUTO_INCREMENT PRIMARY KEY, "
	  	  		                   + "nome VARCHAR(100) NOT NULL, "
	  	  		                   + ")";
	  	  
	  	  String tabellaPosts = "CREATE TABLE IF NOT EXISTS posts ("
	  	  		              + "id INT AUTO_INCREMENT PRIMARY KEY, "
	  	  		              + "titolo VARCHAR(100) NOT NULL, "
	  	  		              + "immagine VARCHAR(250), "
	  	  		              + "data_post TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
	  	  		              + "id_utente INT NOT NULL, "
	  	  		              + ")";
	  	  
	  	  String tabellaCommentiPosts = "CREATE TABLE IF NOT EXISTS commenti_posts ("
	  	  		                      + "id INT AUTO_INCREMENT PRIMARY KEY, "
	  	  		                      + "data_commento TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
	  	  		                      + "id_utente INT NOT NULL, "
	  	  		                      + "id_post INT NOT NULL "
	  	  		                      + ")";
	  	  		                      
	  	  String tabellaRuoli = "CREATE TABLE IF NOT EXISTS ruoli ("
	  	  		              + "id INT AUTO_INCREMENT PRIMARY KEY, "
	  	  		              + "livello INT NOT NULL, "
	  	  		              + "id_gruppo INT NOT NULL, "
	  	  		              + "id_evento INT NOT NULL, "
	  	  		              + "id_utente INT NOT NULL "
	  	  		              + ")";
	  	  
	  	  String tabellaEventi = "CREATE TABLE IF NOT EXISTS eventi ("
	  	  		               + "id INT AUTO_INCREMENT PRIMARY KEY, "
	  	  		               + "data_inizio DATE NOT NULL, "
	  	  		               + "data_fine DATE NOT NULL, "
	  	  		               + "luogo VARCHAR(50) NOT NULL, "
	  	  		               + "titolo VARCHAR(50) NOT NULL, "
	  	  		               + "descrizione TEXT, "
	  	  		               + "id_interesse INT NOT NULL, "
	  	  		               + "id_utente INT NOT NULL"
	  	  		               + ")";
	  	  
	  	  String tabellaAssets = "CREATE TABLE IF NOT EXISTS assets ("
	  	  						+ "id INT AUTO_INCREMENT PRIMARY KEY, "
	  	  						+ "name VARCHAR(255) NOT NULL, "
	  	  						+ "type ENUM('css', 'js') NOT NULL, "
	  	  						+ "content TEXT NOT NULL"
	  	  						+ ")";
		
		try(Connection conn = DriverManager.getConnection(URL + DB_NAME, user, password);
				Statement stmt = conn.createStatement()){
	  		stmt.executeUpdate(tabellaUtenti);
	  		stmt.executeUpdate(tabellaInteressi);
	  		stmt.executeUpdate(tabellaPosts);
	  		stmt.executeUpdate(tabellaCommentiPosts);
	  		stmt.executeUpdate(tabellaRuoli);
	  		stmt.executeUpdate(tabellaEventi);
			stmt.executeUpdate(tabellaMessaggi);
			stmt.executeUpdate(tabellaAmministratori);
			stmt.executeUpdate(tabellaLikePosts);
			stmt.executeUpdate(tabellaFollowers);
			stmt.executeUpdate(tabellaAmicizie);
			stmt.executeUpdate(tabellaGruppi);
			stmt.executeUpdate(tabellaAssets);
			System.out.println("Le tabelle sono state create con successo!");
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		
	}
	


}
