package cifratura;

import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class EncryptionDecryption {
    private static final String ALGORITHM = "AES";
    private static final int KEY_SIZE = 128;
   //private static SecretKey KEY_GENERATED; 
    
    public static SecretKey generateKey() throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance(ALGORITHM);
         keyGen.init(KEY_SIZE);
        return keyGen.generateKey();
    }

    
    
    // Converte una stringa Base64 in una chiave AES
    public static SecretKey getKeyFromString(String keyStr) {
        byte[] decodedKey = Base64.getDecoder().decode(keyStr);
        return new SecretKeySpec(decodedKey, 0, decodedKey.length, ALGORITHM);
    }

    // Converte una chiave AES in una stringa Base64
//    public static String getStringFromKey(SecretKey key) {
//        byte[] encodedKey = Base64.getEncoder().encode(key.getEncoded());
//        return new String(encodedKey);
//    }

    // Metodo per cifrare una parola
    public static String encrypt(String data, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encryptedData = cipher.doFinal(data.getBytes());
        return Base64.getEncoder().encodeToString(encryptedData);
    }

    // Metodo per decifrare una parola
    public static String decrypt(String encryptedData, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] decodedData = Base64.getDecoder().decode(encryptedData);
        byte[] decryptedData = cipher.doFinal(decodedData);
        return new String(decryptedData);
    }
    
    
 // Metodo per convertire un oggetto SecretKey in una stringa Base64
    public static String getStringFromKey(SecretKey key) {
        byte[] encodedKey = Base64.getEncoder().encode(key.getEncoded());
        return new String(encodedKey);
    }
  
 
}