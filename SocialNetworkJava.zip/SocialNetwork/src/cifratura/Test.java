package cifratura;

import javax.crypto.SecretKey;

public class Test {

	public static void main(String[] args) {

		try {
			EncryptionDecryption ed = new EncryptionDecryption();
			SecretKey sk = ed.generateKey();
			String keyString = ed.getStringFromKey(sk);
			String data ="HelloWorld"; 
			String encryptionData=ed.encrypt(data, sk);
			System.out.println(encryptionData);
			
			String decryptionData =ed.decrypt(encryptionData,sk);
			System.out.println(decryptionData);
		}catch(Exception e) {
			e.printStackTrace();
		}

	}
}
