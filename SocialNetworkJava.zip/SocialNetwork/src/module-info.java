/**
 * 
 */
/**
 * 
 */
module SocialNetwork {
	requires java.sql;
	requires java.desktop;
	requires jdk.httpserver;
}