package gestionehandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.crypto.SecretKey;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import cifratura.EncryptionDecryption;
import test.Utente;

public class AccediHandler implements HttpHandler{
	Utente utente = new Utente();
	
	@Override
	public void handle(HttpExchange exchange) throws IOException {
	
		if(exchange.getRequestMethod().equalsIgnoreCase("post")) {
          
			InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(),"utf-8");
			BufferedReader br = new BufferedReader(isr);
			String formData = br.readLine();
		
			String[] formDataArray = formData.split("&");
			
			String username = formDataArray[0].split("=")[1];
			String password = formDataArray[1].split("=")[1];
            String strSecret="";
			
		
			
			//System.out.println("Ci sono");
			
			if(username.equals("admin")&&password.equals("admin")) {
				System.out.println("Sono in Admin");
				exchange.getResponseHeaders().set("Location","/userAmministratore");
				exchange.sendResponseHeaders(302, -1);
				
			}
 
			else if(utente.login(username,password)) {
				SecretKey secretkey =null;
				String usernameEncrypted="";
                try {
					secretkey =  EncryptionDecryption.generateKey();
					//String keyString = EncryptionDecryption.getStringFromKey(secretkey);
					//System.out.println(secretkey);
					 usernameEncrypted= EncryptionDecryption.encrypt(username, secretkey);
					 strSecret = EncryptionDecryption.getStringFromKey(secretkey);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				System.out.println(secretkey);
				String newUrl ="http://localhost:8080/userPage?username="+usernameEncrypted+"&a="+strSecret;
				
				exchange.getResponseHeaders().set("Location",newUrl);
				exchange.sendResponseHeaders(302, -1);
				//utente.setLogged(username);
			
			}
			else {
				exchange.getResponseHeaders().set("Location","/loginErrato");
				exchange.sendResponseHeaders(302, -1);
			}
		
			
		}
	
		
		else {
			exchange.sendResponseHeaders(405, -1);
		}
		
		
	}

}
