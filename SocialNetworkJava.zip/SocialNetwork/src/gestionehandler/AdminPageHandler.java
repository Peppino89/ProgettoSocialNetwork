package gestionehandler;
//import java.io.BufferedReader;
import java.io.IOException;
//import java.io.InputStreamReader;
import java.io.OutputStream;
//import java.util.ArrayList;
//import java.time.LocalDate;
//import java.util.Calendar;
//import java.util.Date;
//import java.util.TimeZone;
//import java.time.LocalDateTime;
//import java.time.ZoneId;
//import java.time.format.DateTimeFormatter;
//import java.util.List;
//import java.util.Locale;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

//import cifratura.EncryptionDecryption;
//import test.Messaggio;
import test.Utente;
public class AdminPageHandler implements HttpHandler {
	Utente utente = new Utente();
	String user="";
	String	usersk="";
	@Override
	public void handle(HttpExchange exchange) throws IOException {

		if(exchange.getRequestMethod().equalsIgnoreCase("get")) {

			//String[] parameters =exchange.getRequestURI().getQuery().split("&");

//			user = parameters[0].split("=")[1];
//			String sk = parameters[1].split("=")[1];


//			try {
//
//				usersk = EncryptionDecryption.decrypt(user, EncryptionDecryption.getKeyFromString(sk));
//				
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//				System.out.println(usersk);
//			}
//
//			if(utente.getLogged(usersk)) {
			
			StringBuilder response = new StringBuilder();


				response.append("<!DOCTYPE html>\r\n"
						+ "\r\n"
						+ "<html lang='it' xmlns='http://www.w3.org/1999/xhtml'>\r\n"
						+ "<head>\r\n"
						+ "    <meta charset='utf-8' />\r\n"
						+ "    <meta name='viewport' content='width=device-width, initial-scale=1' />\r\n"
						+ "    <meta author='Mattia Bascelli'/>\r\n"
						+ "    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH' crossorigin='anonymous'>\r\n"
						+ "    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js' integrity='sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz' crossorigin='anonymous'></script>\r\n"
						+ "    <title>Admin Page Social Network</title>\r\n"
						+ "</head>\r\n"
						+ "<body>\r\n"
						+ "    <section>\r\n"
						+ "        <div class='container'>\r\n"
						+ "            <h1 class='mt-5 mb-3'>Pagina di TEST</h1>\r\n"
						+ "            <div class='row'>\r\n"
						+ "                <div class='col-sm-6'>\r\n"
						+ "                    <h2>Form Provvisorio TEST</h2>\r\n"
						+ "                     <ul>"
						+ "                        <li><a href='#'>Aggiungi utente</a></li>"
						+ "                        <li><a href='#'>Modifica utente</a></li>"
						+ "                        <li><a href='#'>Elimina utente</a></li>"
						+ "                        <li><a href='#'>VisualizzaUtenti</a></li>                                      "
						+ "                    </ul>"
						+ "                    <hr />\r\n"
						+ "                    <div id='messaggio'>\r\n"
						+ "                        Descrizione\r\n"
						+ "                    </div>\r\n"
						+ "                </div>\r\n"
						+ "                <div class='col-sm-6'>\r\n"
						+ "                    <h2 id='headTabellina'>Tabella</h2>\r\n"
						+ "                    <table class='table'>\r\n"
						+ "                        <thead>\r\n"
						+ "                            <tr>\r\n"
						+ "                                <th>Colonna 1</th>\r\n"
						+ "                                <th>Colonna 2</th>\r\n"
						+ "                                <th>Colonna 3</th>\r\n"
						+ "                            </tr>\r\n"
						+ "                        </thead>\r\n"
						+ "                        <tbody id='tabella'>\r\n"
						+ "                        </tbody>\r\n"
						+ "                    </table>\r\n"
						+ "                </div>\r\n"
						+ "            </div>\r\n"
						+ "        </div>\r\n"
						+ "    </section>\r\n"
						+ "\r\n"
						+ "</body>\r\n"
						+ "</html>");
				exchange.getResponseHeaders().set("Content-Type",  "text/html");
				int contentlength = response.toString().getBytes("UTF-8").length;
				exchange.sendResponseHeaders(200, contentlength);

				//inviamo risposta al client
				OutputStream os = exchange.getResponseBody();
				os.write(response.toString().getBytes());//scriviamo il documento HTML come array di byte
				os.close();//chiudiamo l'os
			//}
//			else {
//				exchange.getResponseHeaders().set("location","/");
//				//exchange.sendResponseHeaders(302, -1); // 302 per la redirezione
//				System.out.println("Non sei loggato");
//
//			}

		}

		else if(exchange.getRequestMethod().equalsIgnoreCase("post")) {
			utente.logout(usersk);

			exchange.getResponseHeaders().set("location","/");
			exchange.sendResponseHeaders(302, -1);


		}

		else {
			exchange.sendResponseHeaders(405, -1);
		}


	}

	
	
}