package test;

public class Test {

	public static void main(String[] args) {

		//Utente user = new Utente("Ciccio","Pasticcio","CiccioPasticcio","1234","Ciccio@gmail.com","03455","pasticcio","Ciccio","1989-12-12","2023-05-06");
		//Utente user2 = new Utente("Luca","Tassiello","LucaTas","8888","Luca@gmail.com","0312","Tass","Luca","1998-12-12","2024-07-06");
		//user2.registra();
//
//		if(user2.aggiungiAmico(1,2)) {
//			System.out.println("Amicizia Accettata");
//		}
//		else {
//			System.out.println("Amicizia Rifiutata");
//		}

		//	if(user.registra()) {
		//		System.out.println("Ok registrazione avvenuta!");
		//	}
		//	else {
		//		System.out.println("Errore nella registrazione");
		//	}


		//	if(user.login("CiccioPasticcio","1234") ) {
		//		System.out.println("Ok sei loggato");
		//		
		//	}
		//	else {
		//		System.out.println("Mi dispiace non sei registrato");
		//	}


		//user.logout();


		//System.out.println(user.getLogged());



		//	




	}

}
