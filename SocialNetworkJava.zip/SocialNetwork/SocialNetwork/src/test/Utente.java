package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.Statement;

public class Utente {

	private int idUtente;
	private int idPost;
	private String nome;
	private String cognome;
	private String username;
	private String email;
	private String password;
	private String interessi;
	private String immagine;
	private String numeroTelefono;
	private String domandaSegreta;
	private String rispostaSegreta;
	private String dataNascita;
	private String dataRegistrazione;
	private String messaggio;
	private boolean isLogged;

	private static final String DB_URL="jdbc:mysql://localhost:3306/social_network";
	private static final String DB_USERNAME="root";
	private static final String DB_PASSWORD="root";


	public Utente(String nome, String cognome, String username, String password,String email,  String numeroTelefono,String domandaSegreta, String rispostaSegreta, String dataNascita, String dataRegistrazione,boolean isLogged) {

		this.nome = nome;
		this.cognome = cognome;
		this.username = username;
		this.email = email;
		this.password = password;
		this.numeroTelefono = numeroTelefono;
		this.domandaSegreta = domandaSegreta;
		this.rispostaSegreta = rispostaSegreta;
		this.dataNascita = dataNascita;
		this.dataRegistrazione = dataRegistrazione;
		this.isLogged = isLogged;
	}

	public Utente() {
		
	}


	public int getIdPost() {
		return idPost;
	}

	public void setIdPost(int idPost) {
		this.idPost = idPost;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	private void setPassword(String password, int idUtente) {
		//this.password = "";
		
		try(Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)){
			conn.setAutoCommit(false);
			try(PreparedStatement pstmt = conn.prepareStatement("UPDATE utenti SET password = ? WHERE id = ? ")){
				pstmt.setString(1,  password);
				pstmt.setInt(2,  idUtente);
				pstmt.executeUpdate();
				conn.commit();
				
				this.password = password;
			}catch(SQLException e) {
				conn.rollback();
				e.printStackTrace();
			}finally {
				conn.setAutoCommit(true);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		

//	    String updateQuery = "UPDATE utenti SET password = ? WHERE id = ?";
//	    
//	    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
//	         PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {
//	        
//	        pstmt.setString(1, newPassword);
//	        pstmt.setInt(2, idUser);
//	        pstmt.executeUpdate();
//	        
//	    } catch (SQLException e) {
//	        e.printStackTrace();
//	    }
		
	}

	public String getInteressi() {
		return interessi;
	}

	public void setInteressi(String interessi) {
		this.interessi = interessi;
	}


	public String getImmagine() {
		return immagine;
	}


	public void setImmagine(String immagine) {

		this.immagine = immagine;
	}


	public String getNumeroTelefono() {
		return numeroTelefono;
	}


	public void setNumeroTelefono(String numeroTelefono) {
		this.numeroTelefono = numeroTelefono;
	}


	public String getDomandaSegreta() {
		return domandaSegreta;
	}


	public void setDomandaSegreta(String domandaSegreta) {
		this.domandaSegreta = domandaSegreta;
	}


	public String getRispostaSegreta() {
		return rispostaSegreta;
	}

	public void setRispostaSegreta(String rispostaSegreta) {

		this.rispostaSegreta = rispostaSegreta;
	}


	public String getDataNascita() {
		return dataNascita;
	}


	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}


	public String getDataRegistrazione() {
		return dataRegistrazione;
	}


	public void setDataRegistrazione(String dataRegistrazione) {
		this.dataRegistrazione = dataRegistrazione;
	}


	public String getMessaggio() {
		return messaggio;
	}

	public void setMessaggio(String messaggio) {
		this.messaggio = messaggio;
	}


	public int getIdUtente() {
		return idUtente;
	}
	public boolean getLogged(String username) {
		
		try(Connection conn = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD)){

			conn.setAutoCommit(false);//disabilitiamo il metodo predefinito della scrittura dati su DB
			try(PreparedStatement pstmt= conn.prepareStatement("SELECT is_logged FROM utenti WHERE username = ?")){
				//inserimento studente
				
               pstmt.setString(1, username);

               
               
				 //esecuzione della query
                 ResultSet rs = pstmt.executeQuery();
                 
                 while(rs.next()){
                 isLogged = rs.getBoolean("is_logged");
                 }
               


				conn.commit();//avvio della transazione
			
                
			}catch(SQLException e) {
				conn.rollback();//metodo per annullare l'inserimento avvenuto in modo parziale
				e.printStackTrace();
			}finally {
				conn.setAutoCommit(true);//riabilitiamo l'autocommit

			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return isLogged;
	}

	
	public void setLogged(String username) {
		
		try(Connection conn = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD)){

			conn.setAutoCommit(false);//disabilitiamo il metodo predefinito della scrittura dati su DB
			try(PreparedStatement pstmt= conn.prepareStatement("UPDATE utenti SET is_logged = ? WHERE username = ?")){
				//inserimento studente
				
//					if(getLogged(username)) {
//					    pstmt.setBoolean(1, false);
//					    pstmt.setString(2, username);
//					}else {
						 pstmt.setBoolean(1, true);
						    pstmt.setString(2, username);
					//}
                     
					
					
					pstmt.executeUpdate();

				 //esecuzione della query
         
				conn.commit();//avvio della transazione
			
                
			}catch(SQLException e) {
				conn.rollback();//metodo per annullare l'inserimento avvenuto in modo parziale
				e.printStackTrace();
			}finally {
				conn.setAutoCommit(true);//riabilitiamo l'autocommit

			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public boolean registra() {
		boolean isRegistered = false;
		try(Connection conn = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD)){

			conn.setAutoCommit(false);//disabilitiamo il metodo predefinito della scrittura dati su DB
			try(PreparedStatement pstmt= conn.prepareStatement("INSERT INTO utenti (nome, cognome, username, password, email, telefono, domanda_segreta,"
					+ "risposta_segreta, data_nascita, data_registrazione,is_logged)VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)"
					);

					){
				//inserimento studente
				pstmt.setString(1, nome);
				pstmt.setString(2, cognome);
				pstmt.setString(3, username);
				pstmt.setString(4, password);
				pstmt.setString(5, email);
				pstmt.setString(6, numeroTelefono);
				pstmt.setString(7, domandaSegreta);
				pstmt.setString(8, rispostaSegreta);
				pstmt.setString(9, dataNascita);
				pstmt.setString(10, dataRegistrazione);
				pstmt.setBoolean(11, isLogged);


				pstmt.executeUpdate(); //esecuzione della query



				conn.commit();//avvio della transazione
				isRegistered=true;
                
			}catch(SQLException e) {
				conn.rollback();//metodo per annullare l'inserimento avvenuto in modo parziale
				e.printStackTrace();
			}finally {
				conn.setAutoCommit(true);//riabilitiamo l'autocommit

			}
		}catch(SQLException e) {
			e.printStackTrace();
		}

		return isRegistered;
	}

	public boolean login(String username, String password) {
		//boolean isLogin = false;

		try(Connection conn = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD)){

			conn.setAutoCommit(false);//disabilitiamo il metodo predefinito della scrittura dati su DB
			try(PreparedStatement pstmt = conn.prepareStatement("SELECT username, password FROM utenti WHERE username = ? AND password = ?")){

				pstmt.setString(1, username);
				pstmt.setString(2,password);

				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) {
					setLogged(username);
				}

				//esecuzione della query


				conn.commit();//avvio della transazione


			}catch(SQLException e) {
				conn.rollback();//metodo per annullare l'inserimento avvenuto in modo parziale
				e.printStackTrace();
			}finally {
				conn.setAutoCommit(true);//riabilitiamo l'autocommit

			}
		}catch(SQLException e) {
			e.printStackTrace();
		}


		return getLogged(username);

	}


	public boolean logout(String username) {
		
		try(Connection conn = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD)){

			conn.setAutoCommit(false);//disabilitiamo il metodo predefinito della scrittura dati su DB
			try(PreparedStatement pstmt= conn.prepareStatement("UPDATE utenti SET is_logged = ? WHERE username = ?")){
				//inserimento studente
				pstmt.setBoolean(1, false);
			    pstmt.setString(2, username);
			    pstmt.executeUpdate();
				 //esecuzione della query
				conn.commit();//avvio della transazione
				return true;
			}catch(SQLException e) {
				conn.rollback();//metodo per annullare l'inserimento avvenuto in modo parziale
				e.printStackTrace();
				return false;
			}finally {
				conn.setAutoCommit(true);//riabilitiamo l'autocommit

			}
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
	
		
	}
	
	public boolean modificaProfilo(int idUtente, String nome, String cognome, String username,String email, String immagine,String numeroTelefono, String interessi) {
		boolean modify = false;
		try(Connection conn = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD)){

			conn.setAutoCommit(false);//disabilitiamo il metodo predefinito della scrittura dati su DB
			try(PreparedStatement pstmt= conn.prepareStatement("UPDATE utenti SET nome = ? , cognome = ?, username = ?, email = ?,"
					                                             + " immagine = ?,telefono = ?, id_interesse = ?"
					                                             + "WHERE id_utente = ?");
				

					){
				//inserimento studente
				pstmt.setString(1, nome);
				pstmt.setString(2, cognome);
				pstmt.setString(3, username);
				pstmt.setString(5, email);
				pstmt.setString(6, numeroTelefono);
				pstmt.setString(7, domandaSegreta);
				pstmt.setString(8, rispostaSegreta);
				pstmt.setString(9, dataNascita);
				pstmt.setString(10, dataRegistrazione);


				pstmt.executeUpdate(); //esecuzione della query



				conn.commit();//avvio della transazione
				modify=true;

			}catch(SQLException e) {
				conn.rollback();//metodo per annullare l'inserimento avvenuto in modo parziale
				e.printStackTrace();
			}finally {
				conn.setAutoCommit(true);//riabilitiamo l'autocommit

			}
		}catch(SQLException e) {
			e.printStackTrace();
		}

		
		
		
		return modify;
	}

	
	public boolean aggiornaProfiloSenzaInteressi (int idUtente, String nome, String cognome, String username, String password, String email, String immagine, String numeroTelefono) {
		boolean modify = false;
		
		try(Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)){
			conn.setAutoCommit(false);
			try(PreparedStatement pstmt = conn.prepareStatement("UPDATE utenti SET nome = ?, cognome = ?, username = ?, password = ?, email = ?, immagine = ?, telefono = ?  WHERE id = ? ")){
				pstmt.setString(1,  nome);
				pstmt.setString(2,  cognome);
				pstmt.setString(3,  username);
				pstmt.setString(4,  password);
				pstmt.setString(5,  email);
				pstmt.setString(6,  immagine);
				pstmt.setString(7,  numeroTelefono);
				pstmt.setInt(8,  idUtente);
				pstmt.executeUpdate();
				conn.commit();
				modify = true;
			}catch(SQLException e) {
				conn.rollback();
				e.printStackTrace();
			}finally {
				conn.setAutoCommit(true);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		
		return modify;
	}
	
	
	public String recuperaPassword(String email,String domandaSegreta,String rispostaSegreta, String newPassword) {
		
		String query = "SELECT id FROM utenti WHERE email = ? AND domanda_segreta = ? AND risposta_segreta = ?";
		
		try(Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)){
			conn.setAutoCommit(false);
			try(PreparedStatement pstmt = conn.prepareStatement(query)){
				pstmt.setString(1,  email);
				pstmt.setString(2,  domandaSegreta);
				pstmt.setString(3,  rispostaSegreta);
				
	            ResultSet rs = pstmt.executeQuery();
	            
	            rs.next();
	            
				int idUser = rs.getInt("id");
				
				conn.commit();
				
				setPassword(newPassword, idUser);
				
			}catch(SQLException e) {
				conn.rollback();
				e.printStackTrace();
			}finally {
				conn.setAutoCommit(true);
			}
		}catch(SQLException e) {
			e.printStackTrace();
			
		}
		
		return newPassword;
	}

	
	
	 public boolean aggiungiAmico (int idUtenteSeguace, int idUtenteSeguito) {
		 boolean flag = false;
		 
		 try(Connection conn = DriverManager.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD)){

				conn.setAutoCommit(false);//disabilitiamo il metodo predefinito della scrittura dati su DB
				try(PreparedStatement pstmt= conn.prepareStatement("INSERT INTO amicizie(id_utente_seguace, id_utente_seguito) VALUES(?,?)"
						);

						){
					//inserimento studente
					pstmt.setInt(1, idUtenteSeguace);
					pstmt.setInt(2, idUtenteSeguito);
					
					pstmt.executeUpdate(); //esecuzione della query

					conn.commit();//avvio della transazione
					flag=true;

				}catch(SQLException e) {
					conn.rollback();//metodo per annullare l'inserimento avvenuto in modo parziale
					e.printStackTrace();
				}finally {
					conn.setAutoCommit(true);//riabilitiamo l'autocommit

				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
		 
		 return flag;
		 
	 }


}
