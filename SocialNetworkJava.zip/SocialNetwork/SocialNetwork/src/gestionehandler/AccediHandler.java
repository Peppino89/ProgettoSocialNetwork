package gestionehandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import test.Utente;

public class AccediHandler implements HttpHandler{
	Utente utente = new Utente();
	
	@Override
	public void handle(HttpExchange exchange) throws IOException {
	
		if(exchange.getRequestMethod().equalsIgnoreCase("post")) {
            System.out.println("Sono nel post di AccediHandler");
			InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(),"utf-8");
			BufferedReader br = new BufferedReader(isr);
			String formData = br.readLine();
			//System.out.println("Contenuto di Form Data: "+formData);
			String[] formDataArray = formData.split("&");
			
			String username = formDataArray[0].split("=")[1];
			String password = formDataArray[1].split("=")[1];
          
			
			//boolean log = utente.login(username, password);
			
			System.out.println("Ci sono");
			
			
 
			if(utente.login(username,password)) {
				System.out.println(utente.getLogged(username));
				String newUrl ="http://localhost:8080/userPage?username="+username;
				exchange.getResponseHeaders().set("Location",newUrl);
				exchange.sendResponseHeaders(302, -1);
				//utente.setLogged(username);
			
			}else {
				exchange.getResponseHeaders().set("Location","/loginErrato");
				exchange.sendResponseHeaders(302, -1);
			}
		
			
		}
	
		
		else {
			exchange.sendResponseHeaders(405, -1);
		}
		
		
	}

}
